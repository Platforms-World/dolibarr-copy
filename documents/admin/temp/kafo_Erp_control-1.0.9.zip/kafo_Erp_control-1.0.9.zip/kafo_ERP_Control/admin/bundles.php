﻿<?php
require '../../../main.inc.php';
require_once dol_buildpath('/kafo_ERP_Control/core/lib/saascore.lib.php', 0);
$langs->loadLangs(array('admin', 'saascore@kafo_ERP_Control'));
saascoreRequireAdminRight('write');
saascoreSyncKnownIntegrations($db);
$action = GETPOST('action', 'aZ09');
if ($action === 'add') {
    $code = trim(GETPOST('code', 'alpha'));
    $label = trim(GETPOST('label', 'restricthtml'));
    $description = trim(GETPOST('description', 'restricthtml'));
    $is_active = GETPOST('is_active', 'int');
    if ($code !== '') {
        $sql = "INSERT INTO ".MAIN_DB_PREFIX."saas_bundles(code,label,description,is_active,date_created) VALUES ('".$db->escape($code)."','".$db->escape($label)."','".$db->escape($description)."',".(int)$is_active.",'".dol_print_date(dol_now(), '%Y-%m-%d %H:%M:%S')."')";
        $db->query($sql);
    }
}
llxHeader('', $langs->trans('BundlesCatalog'));
print load_fiche_titre($langs->trans('BundlesCatalog'), '', 'title_setup');
print dol_get_fiche_head(saascoreAdminPrepareHead(), 'bundles', $langs->trans('SaaSCoreSetup'), -1, 'generic');
print '<form method="POST"><input type="hidden" name="token" value="'.newToken().'"><input type="hidden" name="action" value="add">';
print '<table class="noborder centpercent"><tr class="liste_titre"><th>code</th><th>label</th><th>description</th><th>is_active</th><th>&nbsp;</th></tr><tr>';
print '<td><input type="text" name="code"></td><td><input type="text" name="label"></td><td><input type="text" class="minwidth300" name="description"></td><td><input type="checkbox" name="is_active" value="1" checked></td><td><input class="button" type="submit" value="'.$langs->trans('Add').'"></td></tr></table></form><br>';
$resql = $db->query("SELECT code,label,description,is_active FROM ".MAIN_DB_PREFIX."saas_bundles ORDER BY code");
print '<table class="noborder centpercent"><tr class="liste_titre"><th>code</th><th>label</th><th>description</th><th>is_active</th></tr>';
while ($resql && ($obj = $db->fetch_object($resql))) print '<tr class="oddeven"><td>'.dol_escape_htmltag($obj->code).'</td><td>'.dol_escape_htmltag($obj->label).'</td><td>'.dol_escape_htmltag($obj->description).'</td><td>'.(int)$obj->is_active.'</td></tr>';
print '</table>'.dol_get_fiche_end(); llxFooter(); $db->close();


