﻿<?php
require '../../../main.inc.php';
require_once dol_buildpath('/saascore/core/lib/saascore.lib.php', 0);
$langs->loadLangs(array('admin', 'saascore@saascore'));
saascoreRequireAdminRight('write');
saascoreSyncKnownIntegrations($db);
$action = GETPOST('action', 'aZ09');
if ($action === 'add') {
    $code = trim(GETPOST('code', 'alpha'));
    $label = trim(GETPOST('label', 'restricthtml'));
    $module_code = trim(GETPOST('module_code', 'alpha'));
    $default_value = GETPOST('default_value', 'int');
    $description = trim(GETPOST('description', 'restricthtml'));
    if ($code !== '') {
        $sql = "INSERT INTO ".MAIN_DB_PREFIX."saas_limits(code,label,module_code,default_value,description,date_created) VALUES ('".$db->escape($code)."','".$db->escape($label)."','".$db->escape($module_code)."',".(int)$default_value.",'".$db->escape($description)."','".dol_print_date(dol_now(), '%Y-%m-%d %H:%M:%S')."')";
        $db->query($sql);
    }
}
llxHeader('', $langs->trans('LimitsCatalog'));
print load_fiche_titre($langs->trans('LimitsCatalog'), '', 'title_setup');
print dol_get_fiche_head(saascoreAdminPrepareHead(), 'limits', $langs->trans('SaaSCoreSetup'), -1, 'generic');
print '<form method="POST"><input type="hidden" name="token" value="'.newToken().'"><input type="hidden" name="action" value="add">';
print '<table class="noborder centpercent"><tr class="liste_titre"><th>code</th><th>label</th><th>module_code</th><th>default_value</th><th>description</th><th>&nbsp;</th></tr><tr>';
print '<td><input type="text" name="code"></td><td><input type="text" name="label"></td><td><input type="text" name="module_code"></td><td><input type="number" min="0" name="default_value" value="0"></td><td><input type="text" class="minwidth300" name="description"></td><td><input class="button" type="submit" value="'.$langs->trans('Add').'"></td></tr></table></form><br>';
$resql = $db->query("SELECT code,label,module_code,default_value,description FROM ".MAIN_DB_PREFIX."saas_limits ORDER BY module_code, code");
print '<table class="noborder centpercent"><tr class="liste_titre"><th>code</th><th>label</th><th>module_code</th><th>default_value</th><th>description</th></tr>';
while ($resql && ($obj = $db->fetch_object($resql))) print '<tr class="oddeven"><td>'.dol_escape_htmltag($obj->code).'</td><td>'.dol_escape_htmltag($obj->label).'</td><td>'.dol_escape_htmltag($obj->module_code).'</td><td>'.(int)$obj->default_value.'</td><td>'.dol_escape_htmltag($obj->description).'</td></tr>';
print '</table>'.dol_get_fiche_end(); llxFooter(); $db->close();

