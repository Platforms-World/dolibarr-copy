﻿<?php
// Silence is golden.
